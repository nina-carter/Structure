import UIKit

struct V4Resolution {
    var width = 62.8
    var height = 57.4
}

let Resolution1 = V4Resolution ()

print("The width of the V4 engine is \(Resolution1.width)")
print("The height of the V4 engine is \(Resolution1.height)")

struct V6Resolution {
    var width = 67.32
    var height = 53.54
}

let Resolution2 = V6Resolution ()

print("The width of the V6 engine is \(Resolution2.width)")
print("The height of the V6 engine is \(Resolution2.height)")

struct V8Resolution {
    var width = 66.9
    var height = 53.6
}

let Resolution3 = V8Resolution ()

print("The width of the V8 engine is \(Resolution3.width)")
print("The height of the V8 engine is \(Resolution3.height)")
